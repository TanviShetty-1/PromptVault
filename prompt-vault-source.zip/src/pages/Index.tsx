import { useState, useEffect, useMemo } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/hooks/useAuth';
import { Header } from '@/components/Header';
import { SearchBar } from '@/components/SearchBar';
import { QuickTags } from '@/components/QuickTags';
import { PromptCard } from '@/components/PromptCard';
import { CreatePromptModal } from '@/components/CreatePromptModal';
import { CollectionsSidebar } from '@/components/CollectionsSidebar';
import { EmptyState } from '@/components/EmptyState';
import { AuthModal } from '@/components/AuthModal';
import { Plus } from 'lucide-react';
import { toast } from 'sonner';

interface Prompt {
  id: string;
  title: string;
  content: string;
  category: string;
  tags: string[];
  is_favorite: boolean;
  collection_id: string | null;
}

interface Collection {
  id: string;
  name: string;
  emoji: string;
}

const Index = () => {
  const { user } = useAuth();
  const [prompts, setPrompts] = useState<Prompt[]>([]);
  const [collections, setCollections] = useState<Collection[]>([]);
  const [search, setSearch] = useState('');
  const [category, setCategory] = useState('All');
  const [selectedCollection, setSelectedCollection] = useState<string | null>(null);
  const [createOpen, setCreateOpen] = useState(false);
  const [editData, setEditData] = useState<(Prompt & { id: string }) | null>(null);
  const [authOpen, setAuthOpen] = useState(false);

  const fetchPrompts = async () => {
    if (!user) return;
    const { data } = await supabase
      .from('prompts')
      .select('*')
      .eq('user_id', user.id)
      .order('created_at', { ascending: false });
    if (data) setPrompts(data.map(p => ({ ...p, tags: p.tags || [] })));
  };

  const fetchCollections = async () => {
    if (!user) return;
    const { data } = await supabase
      .from('collections')
      .select('*')
      .eq('user_id', user.id)
      .order('created_at', { ascending: false });
    if (data) setCollections(data);
  };

  useEffect(() => {
    if (user) {
      fetchPrompts();
      fetchCollections();
    } else {
      setPrompts([]);
      setCollections([]);
    }
  }, [user]);

  const filtered = useMemo(() => {
    return prompts.filter((p) => {
      if (category === 'Favorites' && !p.is_favorite) return false;
      if (category !== 'All' && category !== 'Favorites' && p.category !== category) return false;
      if (selectedCollection && p.collection_id !== selectedCollection) return false;
      if (search) {
        const q = search.toLowerCase();
        return (
          p.title.toLowerCase().includes(q) ||
          p.content.toLowerCase().includes(q) ||
          p.tags.some((t) => t.toLowerCase().includes(q))
        );
      }
      return true;
    });
  }, [prompts, category, selectedCollection, search]);

  const handleCreate = async (data: { title: string; content: string; category: string; tags: string[] }) => {
    if (!user) return;
    if (editData) {
      await supabase.from('prompts').update({
        title: data.title, content: data.content, category: data.category, tags: data.tags,
      }).eq('id', editData.id);
      setEditData(null);
      toast.success('Prompt updated');
    } else {
      await supabase.from('prompts').insert({
        ...data, user_id: user.id, collection_id: selectedCollection,
      });
      toast.success('Prompt created');
    }
    fetchPrompts();
  };

  const handleToggleFavorite = async (id: string) => {
    const prompt = prompts.find((p) => p.id === id);
    if (!prompt) return;
    await supabase.from('prompts').update({ is_favorite: !prompt.is_favorite }).eq('id', id);
    fetchPrompts();
  };

  const handleDelete = async (id: string) => {
    await supabase.from('prompts').delete().eq('id', id);
    toast.success('Prompt deleted');
    fetchPrompts();
  };

  const handleEdit = (id: string) => {
    const prompt = prompts.find((p) => p.id === id);
    if (prompt) {
      setEditData(prompt);
      setCreateOpen(true);
    }
  };

  const handleCreateCollection = async (name: string, emoji: string) => {
    if (!user) return;
    await supabase.from('collections').insert({ name, emoji, user_id: user.id });
    toast.success('Collection created');
    fetchCollections();
  };

  return (
    <div className="min-h-screen bg-background">
      <Header />

      <main className="max-w-6xl mx-auto px-4 sm:px-6 py-10">
        {/* Hero */}
        <div className="text-center mb-10 space-y-3">
          <h2 className="text-3xl sm:text-4xl font-semibold tracking-tight text-foreground">
            The single source of truth for your AI workflows.
          </h2>
          <p className="text-muted-foreground max-w-lg mx-auto text-sm">
            Centralize your breakthrough prompts. Master your AI workflow with zero friction.
          </p>
        </div>

        {/* Search */}
        <div className="space-y-5 mb-10">
          <SearchBar value={search} onChange={setSearch} />
          <div className="flex items-center justify-between gap-4 flex-wrap">
            <QuickTags selected={category} onSelect={setCategory} />
            {user && (
              <button
                onClick={() => { setEditData(null); setCreateOpen(true); }}
                className="bg-primary text-primary-foreground px-5 py-2.5 rounded-full text-sm font-semibold flex items-center gap-2 shrink-0 hover:opacity-90 hover:-translate-y-0.5 hover:shadow-md transition-all active:translate-y-px border border-primary/20 shadow-[inset_0_1px_0_0_rgba(255,255,255,0.1)]"
              >
                <Plus className="w-4 h-4" />
                New Prompt
              </button>
            )}
          </div>
        </div>

        {/* Content */}
        <div className="flex gap-6 flex-col lg:flex-row">
          {user && collections.length > 0 && (
            <aside className="lg:w-56 shrink-0">
              <CollectionsSidebar
                collections={collections}
                selectedId={selectedCollection}
                onSelect={setSelectedCollection}
                onCreate={handleCreateCollection}
              />
            </aside>
          )}

          <div className="flex-1">
            {filtered.length === 0 ? (
              <EmptyState
                onCreateFirst={() => { setEditData(null); setCreateOpen(true); }}
                isLoggedIn={!!user}
                onSignIn={() => setAuthOpen(true)}
              />
            ) : (
              <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-3 gap-5">
                {filtered.map((prompt, i) => (
                  <PromptCard
                    key={prompt.id}
                    {...prompt}
                    tags={prompt.tags}
                    isFavorite={prompt.is_favorite}
                    onToggleFavorite={handleToggleFavorite}
                    onDelete={handleDelete}
                    onEdit={handleEdit}
                    delay={i * 60}
                  />
                ))}
              </div>
            )}
          </div>
        </div>
      </main>

      <CreatePromptModal
        open={createOpen}
        onOpenChange={(open) => { setCreateOpen(open); if (!open) setEditData(null); }}
        onSubmit={handleCreate}
        initialData={editData}
      />
      <AuthModal open={authOpen} onOpenChange={setAuthOpen} />
    </div>
  );
};

export default Index;
