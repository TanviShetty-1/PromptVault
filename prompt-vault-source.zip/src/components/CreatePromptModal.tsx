import { useState, useEffect } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Plus } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';

const DEFAULT_CATEGORIES = ['Coding', 'Creative', 'Business', 'Marketing', 'Writing', 'Productivity'];

interface CreatePromptModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onSubmit: (data: { title: string; content: string; category: string; tags: string[] }) => void;
  initialData?: { id: string; title: string; content: string; category: string; tags: string[] } | null;
}

export const CreatePromptModal = ({ open, onOpenChange, onSubmit, initialData }: CreatePromptModalProps) => {
  const [title, setTitle] = useState(initialData?.title || '');
  const [content, setContent] = useState(initialData?.content || '');
  const [category, setCategory] = useState(initialData?.category || 'Coding');
  const [tagsInput, setTagsInput] = useState(initialData?.tags?.join(', ') || '');
  const [allCategories, setAllCategories] = useState<string[]>(DEFAULT_CATEGORIES);

  useEffect(() => {
    const fetchCategories = async () => {
      const { data } = await supabase.from('categories').select('name');
      if (data) {
        const custom = data.map(c => c.name).filter(n => !DEFAULT_CATEGORIES.includes(n));
        setAllCategories([...DEFAULT_CATEGORIES, ...custom]);
      }
    };
    if (open) fetchCategories();
  }, [open]);

  useEffect(() => {
    if (initialData) {
      setTitle(initialData.title);
      setContent(initialData.content);
      setCategory(initialData.category);
      setTagsInput(initialData.tags?.join(', ') || '');
    } else {
      setTitle('');
      setContent('');
      setCategory('Coding');
      setTagsInput('');
    }
  }, [initialData, open]);

  const handleSubmit = () => {
    if (!title || !content) return;
    const tags = tagsInput.split(',').map((t) => t.trim()).filter(Boolean);
    onSubmit({ title, content, category, tags });
    onOpenChange(false);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-lg">
        <DialogHeader>
          <DialogTitle className="text-lg font-semibold">
            {initialData ? 'Edit Prompt' : 'Create New Prompt'}
          </DialogTitle>
        </DialogHeader>
        <div className="space-y-4 pt-2">
          <Input
            placeholder="Prompt title..."
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            className="h-11"
          />
          <Textarea
            placeholder="Write your prompt here..."
            value={content}
            onChange={(e) => setContent(e.target.value)}
            rows={5}
            className="text-sm"
          />
          <Select value={category} onValueChange={setCategory}>
            <SelectTrigger className="h-11">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {allCategories.map((c) => (
                <SelectItem key={c} value={c}>{c}</SelectItem>
              ))}
            </SelectContent>
          </Select>
          <Input
            placeholder="Tags (comma-separated)..."
            value={tagsInput}
            onChange={(e) => setTagsInput(e.target.value)}
            className="h-11"
          />
          <button
            onClick={handleSubmit}
            className="w-full h-11 bg-primary text-primary-foreground rounded-lg text-sm font-medium flex items-center justify-center gap-2 hover:opacity-90 transition-opacity"
          >
            <Plus className="w-4 h-4" />
            {initialData ? 'Update Prompt' : 'Add Prompt'}
          </button>
        </div>
      </DialogContent>
    </Dialog>
  );
};
