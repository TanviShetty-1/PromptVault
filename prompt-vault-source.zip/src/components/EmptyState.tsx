import { Search } from 'lucide-react';

interface EmptyStateProps {
  onCreateFirst: () => void;
  isLoggedIn: boolean;
  onSignIn: () => void;
}

export const EmptyState = ({ onCreateFirst, isLoggedIn, onSignIn }: EmptyStateProps) => (
  <div className="flex flex-col items-center justify-center py-20 text-center space-y-5 animate-fade-in">
    {/* Minimalist SVG illustration */}
    <div className="relative w-24 h-24 text-muted-foreground/30">
      <svg viewBox="0 0 96 96" fill="none" xmlns="http://www.w3.org/2000/svg" className="w-full h-full">
        {/* Cloud */}
        <ellipse cx="48" cy="52" rx="28" ry="16" fill="currentColor" opacity="0.3" />
        <ellipse cx="38" cy="44" rx="16" ry="12" fill="currentColor" opacity="0.2" />
        <ellipse cx="56" cy="46" rx="14" ry="10" fill="currentColor" opacity="0.2" />
        {/* Magnifying glass */}
        <circle cx="44" cy="38" r="14" stroke="currentColor" strokeWidth="2.5" opacity="0.6" />
        <line x1="54" y1="48" x2="64" y2="58" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" opacity="0.6" />
      </svg>
    </div>
    <div className="space-y-2">
      <h2 className="text-xl font-semibold text-foreground">No prompts yet</h2>
      <p className="text-muted-foreground max-w-sm text-sm">
        {isLoggedIn
          ? 'Start building your collection. Your first prompt is just a click away.'
          : 'Sign in to start saving and organizing your best prompts.'}
      </p>
    </div>
    {isLoggedIn ? (
      <button
        onClick={onCreateFirst}
        className="bg-primary text-primary-foreground px-5 py-2.5 rounded-lg text-sm font-medium hover:opacity-90 transition-opacity"
      >
        Create your first prompt
      </button>
    ) : (
      <button
        onClick={onSignIn}
        className="bg-primary text-primary-foreground px-5 py-2.5 rounded-lg text-sm font-medium hover:opacity-90 transition-opacity"
      >
        Sign in to get started
      </button>
    )}
  </div>
);
