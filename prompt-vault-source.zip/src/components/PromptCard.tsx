import { useState } from 'react';
import { Copy, Heart, Edit2, Trash2, Check } from 'lucide-react';
import { cn } from '@/lib/utils';
import { toast } from 'sonner';

interface PromptCardProps {
  id: string;
  title: string;
  content: string;
  category: string;
  tags: string[];
  isFavorite: boolean;
  onToggleFavorite: (id: string) => void;
  onDelete: (id: string) => void;
  onEdit: (id: string) => void;
  delay?: number;
}

const CATEGORY_STYLES: Record<string, { bg: string; text: string }> = {
  Coding: { bg: 'bg-emerald-50 dark:bg-emerald-950/40', text: 'text-emerald-700 dark:text-emerald-400' },
  Creative: { bg: 'bg-fuchsia-50 dark:bg-fuchsia-950/40', text: 'text-fuchsia-700 dark:text-fuchsia-400' },
  Business: { bg: 'bg-blue-50 dark:bg-blue-950/40', text: 'text-blue-700 dark:text-blue-400' },
  Marketing: { bg: 'bg-orange-50 dark:bg-orange-950/40', text: 'text-orange-700 dark:text-orange-400' },
  Writing: { bg: 'bg-violet-50 dark:bg-violet-950/40', text: 'text-violet-700 dark:text-violet-400' },
  Productivity: { bg: 'bg-amber-50 dark:bg-amber-950/40', text: 'text-amber-700 dark:text-amber-400' },
};

const DEFAULT_STYLE = { bg: 'bg-muted', text: 'text-muted-foreground' };

export const PromptCard = ({
  id, title, content, category, tags, isFavorite,
  onToggleFavorite, onDelete, onEdit, delay = 0,
}: PromptCardProps) => {
  const [copied, setCopied] = useState(false);
  const style = CATEGORY_STYLES[category] || DEFAULT_STYLE;

  const handleCopy = async () => {
    await navigator.clipboard.writeText(content);
    setCopied(true);
    toast.success('Prompt copied to clipboard', {
      icon: <Check className="w-4 h-4" />,
      duration: 2000,
    });
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div
      className="card-elevated p-6 flex flex-col opacity-0 animate-slide-up"
      style={{ animationDelay: `${delay}ms` }}
    >
      {/* Header */}
      <div className="flex items-start justify-between gap-3 mb-3">
        <h3 className="font-semibold text-base text-foreground leading-snug">{title}</h3>
        <button
          onClick={() => onToggleFavorite(id)}
          className="shrink-0 transition-all duration-200 hover:scale-110 active:scale-95"
        >
          <Heart
            className={cn(
              'w-4 h-4 transition-all',
              isFavorite
                ? 'fill-amber-400 text-amber-400'
                : 'text-muted-foreground/40 hover:text-muted-foreground'
            )}
          />
        </button>
      </div>

      <p className="text-sm text-muted-foreground line-clamp-3 leading-relaxed mb-4">{content}</p>

      <div className="flex flex-wrap gap-1.5 mt-auto mb-4">
        <span className={cn('px-2.5 py-0.5 rounded-full text-xs font-medium', style.bg, style.text)}>
          {category}
        </span>
        {tags?.slice(0, 2).map((tag) => (
          <span key={tag} className="px-2.5 py-0.5 rounded-full text-xs font-medium bg-muted text-muted-foreground">
            #{tag}
          </span>
        ))}
      </div>

      {/* Footer */}
      <div className="flex items-center justify-between pt-3 border-t border-border">
        <div className="flex items-center gap-1">
          <button
            onClick={() => onEdit(id)}
            className="p-1.5 rounded-md text-muted-foreground hover:bg-muted hover:text-foreground transition-colors"
          >
            <Edit2 className="w-3.5 h-3.5" />
          </button>
          <button
            onClick={() => onDelete(id)}
            className="p-1.5 rounded-md text-muted-foreground hover:bg-destructive/10 hover:text-destructive transition-colors"
          >
            <Trash2 className="w-3.5 h-3.5" />
          </button>
        </div>

        <button
          onClick={handleCopy}
          className={cn(
            'flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-sm font-medium transition-all',
            copied
              ? 'bg-emerald-50 text-emerald-700 dark:bg-emerald-950/40 dark:text-emerald-400'
              : 'bg-primary text-primary-foreground hover:opacity-90'
          )}
        >
          {copied ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
          {copied ? 'Copied' : 'Copy'}
        </button>
      </div>
    </div>
  );
};
