export const PromptVaultLogo = ({ className = "w-8 h-8" }: { className?: string }) => (
  <svg viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg" className={className}>
    {/* P shape - left vertical + top curve */}
    <path
      d="M12 8V40"
      stroke="currentColor"
      strokeWidth="4"
      strokeLinecap="round"
    />
    <path
      d="M12 8H24C30.627 8 36 12.477 36 18C36 23.523 30.627 28 24 28H12"
      stroke="currentColor"
      strokeWidth="4"
      strokeLinecap="round"
      strokeLinejoin="round"
    />
    {/* V shape intertwined */}
    <path
      d="M22 22L30 40L38 22"
      stroke="currentColor"
      strokeWidth="3.5"
      strokeLinecap="round"
      strokeLinejoin="round"
    />
  </svg>
);
