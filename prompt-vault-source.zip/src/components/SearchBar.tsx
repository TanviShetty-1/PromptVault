import { Search } from 'lucide-react';
import { Input } from '@/components/ui/input';

interface SearchBarProps {
  value: string;
  onChange: (value: string) => void;
}

export const SearchBar = ({ value, onChange }: SearchBarProps) => {
  return (
    <div className="relative max-w-2xl mx-auto">
      <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
      <Input
        type="text"
        placeholder="Search prompts..."
        value={value}
        onChange={(e) => onChange(e.target.value)}
        className="h-11 pl-11 pr-20 bg-muted/50 border border-border rounded-full text-sm placeholder:text-muted-foreground focus-visible:ring-1 focus-visible:ring-ring"
      />
      <kbd className="absolute right-4 top-1/2 -translate-y-1/2 hidden sm:inline-flex items-center gap-1 text-[11px] text-muted-foreground bg-background border border-border rounded-md px-1.5 py-0.5 font-mono">
        ⌘K
      </kbd>
    </div>
  );
};
