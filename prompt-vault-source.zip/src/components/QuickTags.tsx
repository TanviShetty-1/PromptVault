import { useState, useEffect } from 'react';
import { cn } from '@/lib/utils';
import { Heart, Plus, Check } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/hooks/useAuth';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { Input } from '@/components/ui/input';

const DEFAULT_CATEGORIES = ['All', 'Coding', 'Creative', 'Business', 'Marketing', 'Writing', 'Productivity'];

const COLOR_OPTIONS = [
  { name: 'Emerald', value: '#10b981' },
  { name: 'Blue', value: '#3b82f6' },
  { name: 'Violet', value: '#8b5cf6' },
  { name: 'Rose', value: '#f43f5e' },
  { name: 'Amber', value: '#f59e0b' },
  { name: 'Cyan', value: '#06b6d4' },
  { name: 'Pink', value: '#ec4899' },
  { name: 'Lime', value: '#84cc16' },
];

interface QuickTagsProps {
  selected: string;
  onSelect: (category: string) => void;
}

export const QuickTags = ({ selected, onSelect }: QuickTagsProps) => {
  const { user } = useAuth();
  const [customCategories, setCustomCategories] = useState<{ name: string; color: string }[]>([]);
  const [popoverOpen, setPopoverOpen] = useState(false);
  const [newName, setNewName] = useState('');
  const [newColor, setNewColor] = useState(COLOR_OPTIONS[0].value);

  useEffect(() => {
    fetchCategories();
  }, []);

  const fetchCategories = async () => {
    const { data } = await supabase.from('categories').select('*');
    if (data) setCustomCategories(data.map(c => ({ name: c.name, color: c.color })));
  };

  const handleCreate = async () => {
    if (!newName.trim()) return;
    await supabase.from('categories').insert({ name: newName.trim(), color: newColor });
    setNewName('');
    setNewColor(COLOR_OPTIONS[0].value);
    setPopoverOpen(false);
    fetchCategories();
  };

  const allCategories = [
    ...DEFAULT_CATEGORIES.map(name => ({ name, isFavorites: name === 'Favorites' ? true : undefined })),
    { name: 'Favorites', isFavorites: true },
    ...customCategories.map(c => ({ name: c.name, color: c.color })),
  ];

  // Deduplicate: Favorites is added explicitly
  const seen = new Set<string>();
  const uniqueCategories = allCategories.filter(c => {
    if (seen.has(c.name)) return false;
    seen.add(c.name);
    return true;
  });

  return (
    <div className="flex flex-wrap gap-2 items-center">
      {uniqueCategories.map((cat) => (
        <button
          key={cat.name}
          onClick={() => onSelect(cat.name)}
          className={cn(
            'px-3.5 py-1.5 rounded-full text-sm font-medium transition-all duration-200 flex items-center gap-1.5 border',
            selected === cat.name
              ? 'bg-foreground text-background border-foreground'
              : 'bg-muted text-muted-foreground border-border hover:bg-muted/80 hover:text-foreground'
          )}
        >
          {'isFavorites' in cat && cat.isFavorites && (
            <Heart className={cn(
              'w-3.5 h-3.5',
              selected === cat.name ? 'fill-current' : ''
            )} />
          )}
          {'color' in cat && cat.color && !('isFavorites' in cat) && (
            <span
              className="w-2.5 h-2.5 rounded-full shrink-0"
              style={{ backgroundColor: cat.color as string }}
            />
          )}
          {cat.name}
        </button>
      ))}

      {user && (
        <Popover open={popoverOpen} onOpenChange={setPopoverOpen}>
          <PopoverTrigger asChild>
            <button className="w-8 h-8 rounded-full border border-dashed border-border text-muted-foreground hover:text-foreground hover:border-foreground/30 flex items-center justify-center transition-colors">
              <Plus className="w-4 h-4" />
            </button>
          </PopoverTrigger>
          <PopoverContent className="w-64 p-4 space-y-3" align="start">
            <p className="text-sm font-semibold text-foreground">Create New Category</p>
            <Input
              placeholder="Category name..."
              value={newName}
              onChange={(e) => setNewName(e.target.value)}
              className="h-9 text-sm"
              onKeyDown={(e) => e.key === 'Enter' && handleCreate()}
            />
            <div>
              <p className="text-xs text-muted-foreground mb-2">Pick a color</p>
              <div className="flex flex-wrap gap-1.5">
                {COLOR_OPTIONS.map((c) => (
                  <button
                    key={c.value}
                    onClick={() => setNewColor(c.value)}
                    className={cn(
                      'w-7 h-7 rounded-full flex items-center justify-center transition-all',
                      newColor === c.value ? 'ring-2 ring-offset-2 ring-offset-popover ring-foreground/30' : ''
                    )}
                    style={{ backgroundColor: c.value }}
                  >
                    {newColor === c.value && <Check className="w-3.5 h-3.5 text-white" />}
                  </button>
                ))}
              </div>
            </div>
            <button
              onClick={handleCreate}
              className="w-full h-9 bg-primary text-primary-foreground rounded-lg text-sm font-medium hover:opacity-90 transition-opacity"
            >
              Add Category
            </button>
          </PopoverContent>
        </Popover>
      )}
    </div>
  );
};
