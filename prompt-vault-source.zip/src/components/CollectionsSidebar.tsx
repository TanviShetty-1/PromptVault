import { useState } from 'react';
import { FolderPlus, Folder } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { cn } from '@/lib/utils';

interface Collection {
  id: string;
  name: string;
  emoji: string;
}

interface CollectionsSidebarProps {
  collections: Collection[];
  selectedId: string | null;
  onSelect: (id: string | null) => void;
  onCreate: (name: string, emoji: string) => void;
}

const EMOJIS = ['📁', '🚀', '💡', '🎨', '📝', '⚡', '🔥', '💎', '🌟', '🎯'];

export const CollectionsSidebar = ({ collections, selectedId, onSelect, onCreate }: CollectionsSidebarProps) => {
  const [creating, setCreating] = useState(false);
  const [newName, setNewName] = useState('');
  const [selectedEmoji, setSelectedEmoji] = useState('📁');

  const handleCreate = () => {
    if (!newName) return;
    onCreate(newName, selectedEmoji);
    setNewName('');
    setCreating(false);
  };

  return (
    <div className="card-elevated p-4 space-y-3">
      <div className="flex items-center justify-between">
        <h3 className="text-xs font-semibold text-muted-foreground uppercase tracking-wider">Collections</h3>
        <button
          onClick={() => setCreating(!creating)}
          className="text-muted-foreground hover:text-foreground transition-colors p-1 rounded-md hover:bg-muted"
        >
          <FolderPlus className="w-4 h-4" />
        </button>
      </div>

      {creating && (
        <div className="space-y-2 p-3 bg-muted/50 rounded-lg animate-scale-in">
          <div className="flex flex-wrap gap-1">
            {EMOJIS.map((e) => (
              <button
                key={e}
                onClick={() => setSelectedEmoji(e)}
                className={cn(
                  'w-7 h-7 rounded-md text-sm flex items-center justify-center transition-all',
                  selectedEmoji === e ? 'bg-primary/10 scale-110 ring-1 ring-primary' : 'hover:bg-muted'
                )}
              >
                {e}
              </button>
            ))}
          </div>
          <div className="flex gap-2">
            <Input
              placeholder="Name"
              value={newName}
              onChange={(e) => setNewName(e.target.value)}
              className="h-8 text-sm"
              onKeyDown={(e) => e.key === 'Enter' && handleCreate()}
            />
            <button
              onClick={handleCreate}
              className="h-8 px-3 bg-primary text-primary-foreground rounded-lg text-xs font-medium hover:opacity-90 transition-opacity"
            >
              Add
            </button>
          </div>
        </div>
      )}

      <div className="space-y-0.5">
        <button
          onClick={() => onSelect(null)}
          className={cn(
            'w-full flex items-center gap-2 px-3 py-2 rounded-lg text-sm font-medium transition-all',
            selectedId === null
              ? 'bg-primary/10 text-primary'
              : 'text-muted-foreground hover:bg-muted hover:text-foreground'
          )}
        >
          <Folder className="w-4 h-4" />
          All Prompts
        </button>
        {collections.map((col) => (
          <button
            key={col.id}
            onClick={() => onSelect(col.id)}
            className={cn(
              'w-full flex items-center gap-2 px-3 py-2 rounded-lg text-sm font-medium transition-all',
              selectedId === col.id
                ? 'bg-primary/10 text-primary'
                : 'text-muted-foreground hover:bg-muted hover:text-foreground'
            )}
          >
            <span>{col.emoji}</span>
            {col.name}
          </button>
        ))}
      </div>
    </div>
  );
};
